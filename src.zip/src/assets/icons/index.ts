import ArrowLeftIcon from './arrow-left.svg';
import VoiceSearchIcon from './voice-search.svg';
import CameraIcon from './camera.svg';
import HistoryIcon from './history.svg';
import CloseIcon from './close.svg';
import HomeIcon from './home.svg';
import NotificationIcon from './notification.svg';
import MenuIcon from './menu.svg';

export {
  ArrowLeftIcon,
  VoiceSearchIcon,
  CameraIcon,
  HistoryIcon,
  CloseIcon,
  HomeIcon,
  NotificationIcon,
  MenuIcon,
};
