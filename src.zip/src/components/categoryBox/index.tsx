import React from 'react';
import {Text, TouchableOpacity} from 'react-native';

import {styles} from './style';

const CategoryBox = ({color, item}) => {
  return (
    <TouchableOpacity style={[styles.categoryBox, {backgroundColor: color}]}>
      <Text style={styles.categoryText}>{item}</Text>
    </TouchableOpacity>
  );
};

export default CategoryBox;
