import React from 'react';
import {Image, Text, TouchableOpacity, View} from 'react-native';

import {styles} from './style';

const HeadLineCard = ({title, publishedBy, publishedAt, image}) => {
  return (
    <TouchableOpacity style={styles.container}>
      <Image source={{uri: image}} style={styles.image} resizeMode="cover" />
      <Text style={styles.title}>{title}</Text>

      <View style={styles.footer}>
        <View style={styles.footerLeft}>
          <Text>{publishedBy}</Text>
          <Text>{publishedAt}</Text>
        </View>
        <View style={styles.footerRight}>
          <Text>Like</Text>
          <Text>Share</Text>
          <Text>More</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default HeadLineCard;
