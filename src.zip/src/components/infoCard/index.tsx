import React from 'react';
import {Text, TouchableOpacity, View} from 'react-native';
import {styles} from './style';

const InfoCard = ({title, description, image}) => {
  return (
    <TouchableOpacity style={styles.container}>
      <View style={styles.content}>
        <Text>{title}</Text>
        <View style={styles.footer}>
          <Text>{description}</Text>
          <Text>{image}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default InfoCard;
