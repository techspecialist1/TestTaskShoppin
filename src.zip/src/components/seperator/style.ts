import {StyleSheet} from 'react-native';
import {COLORS} from '../../theme';

export const styles = StyleSheet.create({
  separator: {
    height: 1,
    backgroundColor: COLORS.grey,
    width: '100%',
  },
});
