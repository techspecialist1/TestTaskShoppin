export const CategoryData = [
    {
        id: 1,
        backgroundColor: 'yellow',
        image: 'image'
    },
    {
        id: 2,
        backgroundColor: 'blue',
        image: 'music'
    },
    {
        id: 3,
        backgroundColor: 'green',
        image: 'study'
    },
    {
        id: 4,
        backgroundColor: 'red',
        image: 'music'
    },
]

export const InfoData = [
    {
        id: 1,
        title: 'gurugram',
        description: 'image',
        image : 'image'
    },
    {
        id: 2,
        title: 'gurugram',
        description: 'image',
        image : 'image'
    },
    {
        id: 3,
        title: 'gurugram',
        description: 'image',
        image : 'image'
    },
    {
        id: 4,
        title: 'gurugram',
        description: 'image',
        image : 'image'
    },
]

export const HeadLinesData = [
    {
        id: 1,
        image : 'https://www.tata.com/content/dam/tata/images/about-us/Desktop/heritage/ratan-tata/ratan_tata_banner_desktop_1920x1080.jpg',
        title: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua',
        publishedBy: 'publisher',
        publishedAt: '10-10-2024'
    },
    {
        id: 2,
        image : 'https://www.tata.com/content/dam/tata/images/about-us/Desktop/heritage/ratan-tata/ratan_tata_banner_desktop_1920x1080.jpg',
        title: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua',
        publishedBy: 'publisher',
        publishedAt: '10-10-2024'
    },
    {
        id: 3,
        image : 'https://www.tata.com/content/dam/tata/images/about-us/Desktop/heritage/ratan-tata/ratan_tata_banner_desktop_1920x1080.jpg',
        title: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua',
        publishedBy: 'publisher',
        publishedAt: '10-10-2024'
    },
    {
        id: 4,
        image : 'https://www.tata.com/content/dam/tata/images/about-us/Desktop/heritage/ratan-tata/ratan_tata_banner_desktop_1920x1080.jpg',
        title: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua',
        publishedBy: 'publisher',
        publishedAt: '10-10-2024'
    },
]