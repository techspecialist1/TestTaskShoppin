import React from 'react';
import {FlatList, StatusBar, Text, View} from 'react-native';
import {CategoryData, HeadLinesData, InfoData} from './data';

import {styles} from './style';
import {
  CategoryBox,
  HeadLineCard,
  InfoCard,
  Input,
  Seperator,
} from '../../components';

const Home = () => {
  const renderHeader = () => (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text>Filter</Text>
        <Text>Logo</Text>
        <Text>Profile</Text>
      </View>
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Google</Text>
      </View>
      <Input />
      <View style={styles.categoryContainer}>
        {CategoryData?.map(item => (
          <CategoryBox
            key={item.id}
            color={item.backgroundColor}
            item={item.image}
          />
        ))}
      </View>
      <Seperator />
      <FlatList
        contentContainerStyle={styles.infoCardList}
        showsHorizontalScrollIndicator={false}
        horizontal={true}
        data={InfoData}
        renderItem={({item}) => (
          <InfoCard
            title={item.title}
            description={item.description}
            image={item.image}
          />
        )}
      />
      <Seperator />
    </View>
  );

  return (
    <>
      <StatusBar
        barStyle={'light-content'}
        translucent={true}
        backgroundColor={'#1f212570'}
      />
      <FlatList
        ListHeaderComponent={renderHeader}
        data={HeadLinesData}
        renderItem={({item}) => (
          <HeadLineCard
            title={item.title}
            publishedBy={item.publishedBy}
            publishedAt={item.publishedAt}
            image={item.image}
          />
        )}
        ItemSeparatorComponent={() => <Seperator />}
      />
    </>
  );
};

export default Home;
