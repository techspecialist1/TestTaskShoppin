import {StyleSheet} from 'react-native';
import {moderateScale} from '../../utils';

export const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    paddingTop: moderateScale(10),
  },
  container: {
    paddingHorizontal: moderateScale(10),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: moderateScale(10),
  },
  titleContainer: {
    height: moderateScale(100),
    justifyContent: 'center',
  },
  titleText: {
    textAlign: 'center',
  },
  categoryContainer: {
    marginTop: moderateScale(10),
    marginBottom: moderateScale(20),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  infoCardList: {
    paddingHorizontal: moderateScale(10),
    marginTop: moderateScale(15),
  },
});
