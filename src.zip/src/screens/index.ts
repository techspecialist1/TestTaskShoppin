export {default as Home} from './home';
export {default as Profile} from './profile/Profile';
export {default as Search} from './search';
export {default as VoiceSearch} from './voiceSearch';
