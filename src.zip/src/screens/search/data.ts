export const searchHistory = [
  {
    id: 1,
    query: 'Best business development strategies for startups',
    timestamp: '2024-12-18T15:32:21Z',
  },
  {
    id: 2,
    query: 'Top interview questions for BDA intern roles',
    timestamp: '2024-12-18T14:12:05Z',
  },
  {
    id: 3,
    query: 'IQ Matrix project best practices',
    timestamp: '2024-12-17T10:25:43Z',
  },
  {
    id: 4,
    query: 'How to prepare mock interviews',
    timestamp: '2024-12-16T09:45:30Z',
  },
  {
    id: 5,
    query: 'Upcoming business development events in 2024',
    timestamp: '2024-12-15T18:20:15Z',
  },
  {
    id: 6,
    query: 'Top SaaS tools for business development',
    timestamp: '2024-12-14T11:03:58Z',
  },
  {
    id: 7,
    query: 'How to improve lead generation skills',
    timestamp: '2024-12-13T13:37:22Z',
  },
  {
    id: 8,
    query: 'Key trends in business development 2025',
    timestamp: '2024-12-12T16:50:11Z',
  },
  {
    id: 9,
    query: 'How to evaluate BDA intern performance',
    timestamp: '2024-12-11T08:22:49Z',
  },
  {
    id: 10,
    query: 'Effective email outreach templates',
    timestamp: '2024-12-10T20:14:33Z',
  },
  {
    id: 11,
    query: 'Tips for building long-term client relationships',
    timestamp: '2024-12-09T14:30:45Z',
  },
  {
    id: 12,
    query: 'Best CRM tools for small businesses',
    timestamp: '2024-12-08T11:20:50Z',
  },
  {
    id: 13,
    query: 'How to create a sales funnel for startups',
    timestamp: '2024-12-07T17:45:32Z',
  },
  {
    id: 14,
    query: 'Effective cold calling techniques',
    timestamp: '2024-12-06T09:55:20Z',
  },
  {
    id: 15,
    query: 'Examples of successful B2B partnerships',
    timestamp: '2024-12-05T16:10:11Z',
  },
  {
    id: 16,
    query: 'How to set and track KPIs for a sales team',
    timestamp: '2024-12-04T20:33:14Z',
  },
  {
    id: 17,
    query: 'Strategies to upsell to existing customers',
    timestamp: '2024-12-03T13:15:55Z',
  },
  {
    id: 18,
    query: 'Impact of AI on business development',
    timestamp: '2024-12-02T08:50:30Z',
  },
  {
    id: 19,
    query: 'Common mistakes in sales pitch presentations',
    timestamp: '2024-12-01T18:22:43Z',
  },
  {
    id: 20,
    query: 'How to negotiate better deals with clients',
    timestamp: '2024-11-30T12:41:22Z',
  },
];
