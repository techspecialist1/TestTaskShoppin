import React, {useState} from 'react';
import {
  FlatList,
  StatusBar,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import {styles} from './style';

import {
  ArrowLeftIcon,
  CameraIcon,
  CloseIcon,
  HistoryIcon,
  VoiceSearchIcon,
} from '../../assets/icons';
import {_, COLORS} from '../../theme';
import {moderateScale} from '../../utils';
import {searchHistory} from './data';
import {useNavigation} from '@react-navigation/native';

type HistoryProps = {
  query: string;
  setSearchQuery?: (value: string) => void;
};

// On Page components exd //

const SearchBox: React.FC<HistoryProps> = ({
  query,
  setSearchQuery = () => {},
}) => {
  const navigation = useNavigation<any>();

  const goBackhandler = () => {
    navigation.goBack();
  };

  return (
    <View
      style={[
        styles.searchBoxCont,
        _['align-center'],
        _['flex-space-between-row'],
      ]}>
      <TouchableOpacity activeOpacity={0.7} onPress={goBackhandler}>
        <ArrowLeftIcon
          fill={COLORS.grey}
          height={moderateScale(20)}
          width={moderateScale(20)}
        />
      </TouchableOpacity>

      <TextInput
        placeholder="Search or type URL"
        autoFocus={true}
        style={[_['body'], styles.textInput]}
        placeholderTextColor={COLORS.grey}
        value={query}
        onChangeText={e => setSearchQuery(e)}
      />

      <View style={[_['flex-space-between-row'], {gap: moderateScale(20)}]}>
        {query ? (
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => setSearchQuery('')}>
            <CloseIcon
              height={moderateScale(27)}
              width={moderateScale(27)}
              fill={COLORS.white}
            />
          </TouchableOpacity>
        ) : (
          <>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => navigation.navigate('VoiceSearch')}>
              <VoiceSearchIcon
                height={moderateScale(27)}
                width={moderateScale(27)}
                fill={COLORS.white}
              />
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.7}>
              <CameraIcon
                height={moderateScale(27)}
                width={moderateScale(27)}
                fill={COLORS.white}
              />
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );
};

const History: React.FC<HistoryProps> = ({
  query,
  setSearchQuery = () => {},
}) => {
  return (
    <TouchableOpacity
      onPress={() => setSearchQuery(query)}
      activeOpacity={0.8}
      style={[_['flex-row'], _['flex-center'], styles.historyQuaryCont]}>
      <View style={[_['flex-center'], styles.historyIconCont]}>
        <HistoryIcon
          fill={COLORS.grey}
          height={moderateScale(20)}
          width={moderateScale(20)}
        />
      </View>
      <Text style={[_['body-1'], {width: '85%'}]}>{query}</Text>
    </TouchableOpacity>
  );
};

// On Page components exd //

const Search = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');

  return (
    <>
      <StatusBar
        barStyle={'light-content'}
        translucent={true}
        backgroundColor={'#1f212570'}
      />
      <View style={[styles.container, _['body-padding']]}>
        <View style={{gap: moderateScale(15)}}>
          <SearchBox query={searchQuery} setSearchQuery={setSearchQuery} />
          <View style={[_['flex-space-between-row']]}>
            <Text style={[_['h3'], {color: COLORS.grey}]}>Recent Searches</Text>
            <TouchableOpacity activeOpacity={0.7}>
              <Text style={[_['h3'], {color: COLORS.grey}]}>
                MANAGE HISTORY
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <FlatList
          data={searchHistory}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listStyle}
          keyExtractor={item => item.id.toString()}
          renderItem={({item}) => (
            <History setSearchQuery={setSearchQuery} query={item.query} />
          )}
        />
      </View>
    </>
  );
};

export default Search;
