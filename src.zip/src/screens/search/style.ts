import {StyleSheet} from 'react-native';
import {COLORS} from '../../theme';
import {moderateScale} from '../../utils';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.primary,
    paddingTop: moderateScale(50),
  },

  searchBoxCont: {
    paddingHorizontal: moderateScale(20),
    backgroundColor: COLORS.secondry,
    borderTopLeftRadius: moderateScale(200),
    borderTopRightRadius: moderateScale(200),
    borderBottomRightRadius: moderateScale(200),
    borderBottomLeftRadius: moderateScale(200),
    gap: moderateScale(10),
  },

  textInput: {
    paddingVertical: moderateScale(15),
    flex: 1,
    height: moderateScale(58),
  },

  historyIconCont: {
    backgroundColor: COLORS.secondry,
    height: moderateScale(30),
    width: moderateScale(30),
    borderRadius: moderateScale(100),
  },

  historyQuaryCont: {
    gap: moderateScale(15),
    paddingVertical: moderateScale(10),
  },

  listStyle: {
    paddingVertical: moderateScale(16),
  },
});
