export const COLORS = {
  blue: '#174EA6', // Blue
  light_grey: '#F1F3F4', // Light grey
  grey: '#9AA0A6', // Grey
  black: '#202124', // Black
  orange: '#E37400', // Orange
  white: '#FFFFFF', // White
  medium_blue: '#4285F4', // Medium blue
  green: '#0D652D', // Green
  red: '#A50E0E', // Red
  light_blue: '#8cb4f8',
  transparent_light_blue: '#8cb4f859',

  primary: '#1F2125',
  secondry: '#303133',
};
