import { COLORS } from "./colors";
import { fontSize, fonts } from "./fonts";
import { _ } from "./styles";
export {
    COLORS, _, fontSize,
    fonts
};
